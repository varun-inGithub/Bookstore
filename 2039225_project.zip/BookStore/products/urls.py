from django.urls import path, include
from . import views
from django.conf import  settings
from django.conf.urls.static import  static

from .views import EsewaVerify, EsewaRequest

app_name = 'products'

urlpatterns = [
    path('', views.IndexView, name = 'index'),
    path('Dashboard/', views.Dashboard, name = 'Dashboard'),
    path('products_add/', views.AddProducts.as_view(), name = 'add'),
    path('all_Order/', views.AllOrders.as_view(), name = 'displayProduct'),
    path('editProduct/<int:pk>/', views.EditProduct.as_view(), name = 'edit'),
    # path('deleteProduct/<int:pk>/', views.DeleteProduct.as_view(), name = 'delete'),
    path('delete/<int:pk>/', views.delete, name ='delete'),
    # path('products/<int:pk>/', views.product_detaile, name='details'),
    path('products/<slug>/', views.product_detaile, name='details'),
    path('cart/<slug>/', views.add_to_cart, name='add_to_cart'),
    path('createOrder/', views.createOrder, name='makeOrder'),
    # path('cart/<int:pk>/', views.cart, name='cart'),
    path('viewCart/', views.viewCart, name = 'view_cart'),
    path('removeItem/<slug>/', views.deleteItems, name = 'remove_item_cart'),
    path('searchQuery/', views.searchResult, name = 'search'),
    path('filtering/', views.Filtering.as_view(), name = 'filter'),
    path('checkOut/', views.checkout, name='CheckOut'),
    path("esewa-request/", EsewaRequest.as_view(), name="esewarequest"),
    path("esewa-verify/", EsewaVerify.as_view(), name="esewaverify"),
    path('delete_cart_item/<int:pk>/', views.deleteCartItems, name = 'delete_cart_items'),
    path('updateQuantity/<int:pk>/', views.updateCartQuantity, name= 'updateCart'),
    path('orderDetails/<int:pk>/', views.orderDetails, name = 'orderDetails'),

              ]+ static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)