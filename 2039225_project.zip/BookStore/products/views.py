import datetime
import json
from django.contrib import messages

from django.views import View
import requests as req
import requests
from django.shortcuts import render, redirect, get_object_or_404, HttpResponse
from django.template import context
from django.urls import reverse_lazy
from requests import request
from rest_framework.renderers import JSONRenderer

from .forms import AddForm
import json
from .models import *
from django.views.generic import ListView, UpdateView, DetailView, CreateView, DeleteView

from .decoraters import unauthenticated_users, allowed_user, roles
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import Permission, User
from django.utils import timezone
from notifications.signals import notify

from django.contrib.auth.models import Group

from rest_framework.generics import ListAPIView
from rest_framework.filters import  SearchFilter
from .serializer import ProductSerializer

from .filtering import ProductFilter
# Create your views here.
def IndexView(request):
    products = Product.objects.all()
    user = request.user
    if user.is_authenticated:
        groups = user.groups.all()
        groupName = groups[0].name
        myForm = ProductFilter
        context = {'gName': groupName, 'products': products, 'filter': myForm}
        print(groupName)
        return render(request, 'products/home1.html', context)

    else:
        groupName = ''
        context = {'gName': groupName, 'products': products}
        return render(request, 'products/home1.html', context)


# class IndexView(ListView):
#     model = Product
#     template_name = 'products/home1.html'
#
#     def get_context_data(self, *args, **kwargs):
#         user = request.user
#
#         if User.is_authenticated:
#             context = {'c': 'yes'}
#             print('yeo')
#             return context


# @login_required(login_url='login')
# @allowed_user(allowed_roles=['Sellers'])
# def sellerDasboard(request):
#     return render(request, 'testLogin/sellerDashboard.html')
# @login_required(login_url='login')
# @allowed_user(allowed_roles=['Sellers'])

@method_decorator(login_required(login_url='login'), name='dispatch')
@method_decorator(allowed_user(['Sellers']), name='dispatch')
class AddProducts(CreateView, ListView):
    model = Product
    template_name = 'products/add_products.html'
    form_class = AddForm

    # fields = '__all__'
    success_url = reverse_lazy('products:add')


class AllOrders(ListView):
    model = Order
    template_name = 'products/allOrder.html'

    # fields = '__all__'
    success_url = reverse_lazy('products:add')

def orderDetails(request, pk):
    pkey = pk
    orders = Order.objects.filter(id=pkey)
    Shipping = ShippingAddress.objects.get(finalOrder__id=pkey)
    for order in orders:
        queryset = order.products.all()
    context = {'orders': queryset, 'shippingAddress': Shipping}
    for q in queryset:
        print(q.product.product_name)
    return render(request, 'products/orderDetails.html',context)


def DisplayProducts(request):
    orderedBooks = OrderBook.objects.all()
    print('you are here')
    return render(request, 'products/add_products.html', {'orderedBooks': orderedBooks})




# @method_decorator(login_required(login_url='login'), name='dispatch')
# @method_decorator(allowed_user(['Sellers']), name='dispatch')
# class Dashboard():
#     template_name = 'products/seller_Dashboard.html'
#
#     # fields = '__all__'
#     success_url = reverse_lazy('products:Dashboard')

def Dashboard(request):
    esewaCount = ShippingAddress.objects.filter(payment_method = 'Esewa').count()
    cashOndelivery = ShippingAddress.objects.filter(payment_method = 'Cash on Delivery').count()
    print(cashOndelivery)
    print(esewaCount)
    educational_booksCount = Product.objects.filter(product_category = 'Educational').count()
    inspirational_booksCount =  Product.objects.filter(product_category = 'Inspirational').count()
    entertainment_booksCount =  Product.objects.filter(product_category = 'Entertainment').count()
    novel_booksCount =  Product.objects.filter(product_category = 'Novel').count()
    # print(educational_booksCount)
    # print(inspirational_booksCount)
    # print(novel_booksCount)
    user = request.user
    all_user = User.objects.all()
    context = {'user': user, 'all_user': all_user,'cashOndelivery': cashOndelivery, 'esewaCount': esewaCount ,'educational_booksCount': educational_booksCount, 'inspirational_booksCount': inspirational_booksCount, 'entertainment_booksCount': entertainment_booksCount, 'novel_booksCount': novel_booksCount}
    return render(request, 'products/seller_Dashboard.html', context)


class EditProduct(UpdateView):
    model = Product
    template_name = 'products/add_products.html'
    form_class = AddForm
    pk_url_kwarg = 'pk'
    success_url = reverse_lazy('products:add')


# class DeleteProduct(DeleteView):
#     model = Product
#     pk_url_kwarg = 'pk'
#     success_url = reverse_lazy('products:add')
#     template_name = 'products/conform_delete.html'

def delete(request, pk):
    product = Product.objects.get(id=pk)
    product.delete()
    return redirect('/products_add')


def product_detaile(request, slug):
     product = Product.objects.get(book_code=slug)
     context = {'object': product}
     return render(request, 'products/product_details.html', context)

# class Item_details(DetailView):
#     model = Product
#     template_name = "products/product_details.html"

# class checkOut(DetailView):
#     model = Order
#     template_name = "products/checkOut.html"

@login_required(login_url='login')
def checkout(request):
    user = request.user
    user1 = User.objects.get(username=user)
    finalOrder = Order.objects.get(user = user1)
    obj = Order.objects.get(user=user)
    amt = obj.Total_Amount
    # print(finalOrder.id)
    # firstName = user1.first_name
    # lastName = user1.last_name
    # email = user1.email
    if request.method == 'POST':

        districtName = request.POST.get('districtName')
        areaName = request.POST.get('areaName')
        paymentOption = request.POST.get('paymentOption')

        print(paymentOption)
        shipping = ShippingAddress(user = user, finalOrder= finalOrder, district_name= districtName, area_name= areaName, payment_method= paymentOption)
        shipping.save()
        obj = Order.objects.get(user=user)
        amt = obj.Total_Amount
        context = {'amount': amt}
        return render(request, 'products/paymentOption.html',context)

    context = {'user': user1, 'amount':amt}
    return render(request, 'products/checkout.html', context)


def cart(request, pk):
    product = Product.objects.get(id=pk)
    product_name = product.product_name
    product_category = product.product_category
    product_price = product.product_price
    product_image = product.product_image
    quantity = request.GET.get('quantity')
    print(quantity)
    item = Cart(product_name=product_name, product_category=product_category, product_price=product_price,
                product_image=product_image,
                product_quantity=quantity)
    item.save()
    return redirect('products:index')


def add_to_cart(request, slug):
    book = get_object_or_404(Product, book_code=slug)
    order_book, created = OrderBook.objects.get_or_create(
        product=book,
        user=request.user,
        ordered=False,
        is_purchased=False,

    )
    order_qs = Order.objects.filter(user=request.user, ordered=False)

    if order_qs.exists():
        order = order_qs[0]
        # Check if the orderered item is already in the order database
        if order.products.filter(product__book_code=book.book_code).exists():
            order_book.quantity += 1
            order_book.save()

        else:
            order.products.add(order_book)

    else:
        ordered_date = timezone.now()
        order = Order.objects.create(user=request.user, ordered_date=ordered_date)
        order.products.add(order_book)

    TotalOrder = Order.objects.get(user=request.user)
    o = TotalOrder.products.all()
    for q in o:
        print(q.product.product_name)
        print(q.quantity)

    return redirect("products:index")


def createOrder(request):
    # totalOrderedBooks = OrderBook.objects.filter(user=request.user)
    # print(request.user)
    # for books in totalOrderedBooks:
    #     getbooks = FinalOrderBook(user= request.user, product= books.product, quantity= books.quantity)
    #     getbooks.save()
    # totalOrder = Order.objects.get(user= request.user)
    # obj = totalOrder.products.all()
    # print(obj)
    # instance = FinalOrderBook.objects.filter(user = request.user)
    # for books in obj:
    #     gotbooks = FinalOrder(user=books.user, ordered_date= totalOrder.ordered_date)
    #
    #     print(books.product)
    #     gotbooks.save()
    user = request.user
    allbooks = OrderBook.objects.filter(user=user)
    for all in allbooks:
        obj = Order.objects.get(user=user)
        obj.Total_Amount = obj.Total_Amount + all.product.product_price * all.quantity
        obj.save()
    totalAmount = Order.objects.get(user=user)
    amt = totalAmount.Total_Amount
    context = {'amount': amt}

    return render(request, 'products/checkout.html', context)






# def messages(request):
#     if request.method == 'POST':
#         sender = User.objects.get(username=request.user)
#         receiver = User.objects.get(username='Test300')
#         notify.send(sender, recipient=receiver, verb='Message', description='Test')
#         return redirect('products:view_cart')
#     else:
#         return HttpResponse("Invalid request")


# def messagesIndex(request):
#     users = User.objects.all()
#     print(request.user)
#     user = User.objects.get(username=request.user)
#     return render(request, 'products/seller_Dashboard.html', {'users': users, 'user': user})
#     return redirect('products:view_cart')


def viewCart(request):
    user= request.user
    print(user)
    items = OrderBook.objects.filter(user = user, is_purchased = False)
    context = {'items': items}
    return render(request, 'products/cart.html', context)


def deleteCartItems(request, pk):
    pkey = pk
    cartItems = OrderBook.objects.get(product__id = pkey)
    cartItems.delete()
    return redirect('/viewCart')

def updateCartQuantity(request,pk):
    print('lul')
    pkey = pk
    # book = Books.objects.get(id=id)
    quantity = request.POST.get('updateQuantity')
    update = OrderBook.objects.get(id= pkey)
    update.quantity = quantity
    update.save()
    print(quantity)

    return redirect('/viewCart')

def deleteItems(request, slug):
    book = get_object_or_404(Product, slug=slug)
    print(book.product_name)
    # deleteBook = OrderBook.objects.get(product__slug = slug)
    deleteBook = OrderBook.objects.get(user=request.user, product__slug=slug)

    deleteBook.delete()
    # order_qs = Order.objects.filter(user=request.user, ordered=False)
    #
    # if order_qs.exists():
    #     order = order_qs[0]
    #     # Check if the orderered item is already in the order database
    #     if order.products.filter(product__slug=book.slug).exists():
    #         order_book, created = OrderBook.objects.filter(
    #             product=book,
    #             user=request.user,
    #             ordered=False
    #         )[0]
    #
    #         order.products.remove(order_book)
    #
    #     else:
    #         return  redirect("products:details", slug =slug)
    #
    # else:
    #     return  redirect("products:details", slug= slug)
    return redirect("products:details", slug)
# class QueryResult():
#
#     def test(self, *args, **kwargs):
#         if request.method == 'GET':
#             searchTerm = request.GET.get('search')
#             print("This is it")
#             print(searchTerm)
#             response = requests.get('http://127.0.0.1:8000/searchQuery/?format=json&search=', + searchTerm).json
#             context = {'response': response}
#
#             print(response)
#
#         return render(request, 'products/searchResults.html')




# class ProductList(ListAPIView):
#     queryset = Product.objects.all()
#     serializer_class = ProductSerializer
#     filter_backends = [SearchFilter]
#     search_fields = ['product_name']
#
#     # def QueryResult(self,request, *args, **kwargs):
#     #     if request.method == 'GET':
#     #         searchTerm = request.GET.get('search')
#     #         print("This is it")
#     #         print(searchTerm)
#     #         response = requests.get('http://127.0.0.1:8000/searchQuery/?format=json&search=', + searchTerm).json
#     #         print(response)
#     #         context = {'response': response}
#     #
#     #         print(response)
#     #         return render(request, 'products/searchResults.html', context)
#
#
#
#


def searchResult(request):
    query = request.GET.get('search')
    allProducts = Product.objects.filter(product_name__icontains= query)
    context= {'allProducts': allProducts}
    return render(request, 'products/searchResults.html',context)

class Filtering(ListView):
    model = Product
    template_name = 'products/searchResults.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['filter'] = ProductFilter(self.request.GET, queryset=self.get_queryset())
        return context


class EsewaRequest(View):

    def get(self, request, *args, **kwargs):
        # val = request.POST.get('paymentOption')
        # if val== None:
        #     user = request.user
        #     sh = ShippingAddress.objects.get(user= user, is_paid=False)
        #     sh.payment_method = 'Cash On Delivery'
        #     sh.save()
        #     return redirect('/')
        # else:
        user = request.user
        order = Order.objects.get(user= user)
        totalAmount = Order.objects.get(user= user)
        amt = totalAmount.Total_Amount

        context= {'totalAmount': amt, 'order': order}
        return render(request, 'products/esewaRequest.html', context)

class EsewaVerify(View):

    def get(self, request, *args, **kwargs):
        import xml.etree.ElementTree as ET

        oid = request.GET.get('oid')
        amt = request.GET.get('amt')
        refID = request.GET.get('refId')
        url = "https://uat.esewa.com.np/epay/transrec"
        d = {
            'amt': amt,
            'scd': 'EPAYTEST',
            'rid': refID,
            'pid': oid,
        }
        resp = req.post(url, d)
        root = ET.fromstring(resp.content)
        status = root[0].text.strip()

        if status == 'Success':
            messages.success(request, 'Your Order has been placed')
            sender = User.objects.get(username=request.user)
            receiver = User.objects.get(username='Seller001')
            notify.send(sender, recipient=receiver, verb='Message', description='Test')
            print('Payment Done')
            user = request.user
            sh = ShippingAddress.objects.get(user= user, is_paid=False)
            sh.payment_method = 'Esewa'
            sh.is_paid= True
            sh.save()

            todelete= OrderBook.objects.filter(user= request.user, is_purchased=False)
            for to in todelete:
                to.is_purchased = True
                to.save()



            return redirect('/')

        else:
            return redirect('/error')