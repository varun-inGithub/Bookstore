from django.db import models
from django.shortcuts import reverse
from django.conf import settings

# Create your models here.
from django.utils import timezone


class Product(models.Model):
    product_name = models.CharField(max_length=100, null=True)
    product_author = models.CharField(max_length=100, null=True)
    product_category = models.CharField(max_length=50, null=True)
    product_price = models.IntegerField(null=True)
    product_image = models.ImageField(null= True, blank= True, upload_to= "books")
    book_code = models.SlugField(unique =  True)
    added_date = models.DateTimeField(default=timezone.now)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-added_date']

    def __str__(self):
        return self.product_name

    def get_absolute_url(self):
        return reverse("products:details", kwargs={
            'slug': self.book_code
        })

    def get_add_to_cart_url(self):
        return reverse("products:add_to_cart", kwargs={
            'slug': self.book_code
        })

    def get_remove_from_cart_url(self):
        return reverse("products:remove_item_cart", kwargs={
            'slug': self.book_code
        })



class OrderBook(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE ,null=True, blank=True)
    ordered = models.BooleanField(default=False)

    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    is_purchased = models.BooleanField(default=False, null=True, blank=True)


    def __str__(self):
        return f"{self.quantity} of {self.product.product_name}"

#
# class FinalOrderBook(models.Model):
#     user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE ,null=True, blank=True)
#     ordered = models.BooleanField(default=False)
#     product = models.ForeignKey(Product, on_delete=models.CASCADE)
#     quantity = models.IntegerField(default=1)
#
#     def __str__(self):
#         return f"{self.quantity} of {self.product.product_name}"

class Cart(models.Model):
    product_name = models.CharField(max_length = 100, null= True)
    product_category = models.CharField(max_length=50, null= True)
    product_price = models.IntegerField(null= True)
    product_image = models.ImageField(null= True, blank= True, upload_to= "books")
    product_quantity = models.IntegerField(null= True)

    def __str__(self):
        return  self.product_name
class Order(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE ,null=True, blank=True)
    products = models.ManyToManyField(OrderBook)
    Total_Amount = models.IntegerField(default=0, null=True, blank=True)

    start_date = models.DateTimeField(auto_now_add= True)
    ordered_date = models.DateField()
    ordered = models.BooleanField(default=False)

    def __str__(self):
        return self.user.username


# class FinalOrder(models.Model):
#     user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE ,null=True, blank=True)
#     products = models.ManyToManyField(FinalOrderBook, null=True)
#     # Ordered_Quantity = models.IntegerField(null=True, blank=True)
#     Total_Amount = models.IntegerField(null=True, blank=True)
#     ordered_date = models.DateField()
#     ordered = models.BooleanField(default=False)
#
#     def __str__(self):
#         return self.user.username

class ShippingAddress(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE ,null=True, blank=True)
    finalOrder = models.ForeignKey(Order, on_delete=models.CASCADE, null= True, blank=True)
    district_name = models.CharField(max_length=100, null=True, blank=True)
    area_name = models.CharField(max_length=100, null=True, blank=True)
    payment_method = models.CharField(max_length=100, null=True, blank=True)
    is_paid = models.BooleanField(default= False, null=True, blank=True)
