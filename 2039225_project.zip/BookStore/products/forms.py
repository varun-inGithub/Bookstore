from django import forms
from .models import *


class AddForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['product_name','product_author', 'product_category', 'product_price', 'added_date', 'product_image', 'book_code']

