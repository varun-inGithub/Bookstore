from rest_framework import serializers

class ProductSerializer(serializers.Serializer):
    product_name = serializers.CharField(max_length=100)
    product_category = serializers.CharField(max_length=100)