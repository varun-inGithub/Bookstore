from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.loginUser, name='login'),
    path('register/', views.SignUp, name='register'),

    # path('signUp/', views.SignUp ,name = 'signUp'),
    path('home/', views.home, name = 'home'),
    path('logout/', views.logoutuser, name='Logout'),
    path('', views.indexPage, name='index'),
    path('adminDashboard/', views.adminDashboard, name = 'adminDashboard'),
    # path('sellerDashboard/', views.sellerDasboard, name='sellerDashboard'),

]
