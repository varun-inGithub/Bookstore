from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from django.views import View
from django.contrib.auth.forms import UserCreationForm
from .forms import CustomerLoginForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import auth
from .decoraters import unauthenticated_users, allowed_user, roles
from django.contrib.auth.models import Group, User


# Create your views here.
@unauthenticated_users
def loginUser(request):
    if request.method == 'POST':
        username = request.POST.get('your_name')
        password = request.POST.get('your_pass')
        print(username)
        user = authenticate(request, username=username, password=password)
        if(user):
            groups = user.groups.all()
            groupName = groups[0].name
            print(groupName)


            if groupName == 'Sellers':
                login(request,user)
                return redirect('/Dashboard')

            elif groupName == 'Admins':
                login(request, user)
                return redirect('adminDashboard')

            elif groupName == 'Customers':
                login(request, user)
                return redirect('/')


        else:
            messages.error(request, 'Wrong Username Or Password!! Please try Again')
            return render(request, 'testLogin/tempLogin.html')

    context = {}
    return render(request, 'testLogin/tempLogin.html', context)


@unauthenticated_users
def SignUp(request):
    print('You are here')
    # form = CustomerLoginForm()
    if request.method == 'POST':
        first_name = request.POST['fname']
        last_name = request.POST['lname']
        username = request.POST['uname']
        email = request.POST['email_add']
        password = request.POST['pass1']
        c_password= request.POST['pass2']

        if (username):
            print(username)
            print(email)
            print(password)
            # form = CustomerLoginForm(request.POST)
            user = User.objects.create_user(username = username, password= password, email= email, first_name= first_name, last_name= last_name)
            user.save()
            group = Group.objects.get(name= 'Customers')
            user.groups.add(group)
            print('user Created')
            messages.success(request, 'User registered for MR. ' + username + 'You can login Now')
            return redirect('login')



        else:
            messages.error(request, 'Please Enter all the fields')
            return redirect('login')
        # if form.is_valid():
        #     user = form.save()
        #     userName = form.cleaned_data.get('username')
        #     group = Group.objects.get(name= 'Sellers')
        #     user.groups.add(group)
        #     messages.success(request, 'User registered for MR. ' + userName + 'You can login Now')
        #     return redirect('login')
    # context = {'form': form}

    else:
        return render(request, 'testLogin/tempLogin.html')


@login_required(login_url='login')
def home(request):
    return render(request, 'testLogin/home.html')


def logoutuser(request):
    logout(request)
    return redirect('/auth/login')


def indexPage(request):
    return render(request, 'testLogin/index.html')

@login_required(login_url='login')
@allowed_user(allowed_roles=['Admins'])
def adminDashboard(request):
    return render(request, 'testLogin/adminDashboard.html')

# @login_required(login_url='login')
# @allowed_user(allowed_roles=['Sellers'])
# def sellerDasboard(request):
#     return render(request, 'testLogin/sellerDashboard.html')