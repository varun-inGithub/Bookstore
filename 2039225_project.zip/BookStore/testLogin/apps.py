from django.apps import AppConfig


class TestloginConfig(AppConfig):
    name = 'testLogin'
