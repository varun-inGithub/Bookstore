from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms


class CustomerLoginForm(UserCreationForm):

    password1 = forms.CharField(
        widget = forms.PasswordInput(attrs={'placeholder': 'Enter password'})
    )
    password2 = forms.CharField(
        widget = forms.PasswordInput(attrs={'placeholder': 'Re-Enter Password'})
    )
    class Meta:
        model = User

        fields = ['username', 'email']
        widgets= {
            'username': forms.TextInput(attrs={'placeholder': 'Your nane'}),
            'email': forms.EmailInput(attrs = {'placeholder': 'Your Email', 'required': 'true'}),


        }
