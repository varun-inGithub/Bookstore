from django.http import JsonResponse
from django.shortcuts import render, HttpResponse
# from products.models import FinalOrderBook
from .models import Ratings
# from products.models import Product
# Create your views here.

def ratings(request):
    user = request.user
    items = Ratings.objects.filter(user= user, rating_score=0).order_by("?").first()
    context = {'items': items, 'range': range(3)}
    return render(request, 'ratings/review.html', context)


def rate_book(request):
    if request.method == 'POST':
        el_id = request.POST.get('el_id')
        val = request.POST.get('val')
        # obj = Product.objects.filter(id = el_id)
        obj = Ratings.objects.get(product__id = el_id)
        obj.rating_score = val
        obj.save()
        return JsonResponse({'success': 'true', 'score': val}, safe=False)

    return JsonResponse({'success': 'false'})

