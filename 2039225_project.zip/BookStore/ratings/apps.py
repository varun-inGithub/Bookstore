from django.apps import AppConfig


class RatingsConfig(AppConfig):
    name = 'ratings'
