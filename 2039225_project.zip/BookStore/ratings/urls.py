from django.urls import path
from . import views


app_name = 'products'

urlpatterns = [
    path('', views.ratings, name = ''),
    path('books/', views.rate_book, name = 'rateBooks')


              ]