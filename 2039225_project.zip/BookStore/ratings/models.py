from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from products.models import Product


# Create your models here.

class Ratings(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.OneToOneField(Product, on_delete=models.CASCADE)
    rating_score = models.IntegerField(default=0,
                                       validators= [
                                           MaxValueValidator(5),
                                           MinValueValidator(0),
                                       ]
                                       )

    def __str__(self):
        return str(self.product.product_name)